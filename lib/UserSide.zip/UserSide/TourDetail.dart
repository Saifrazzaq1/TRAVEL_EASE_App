import 'package:flutter/services.dart';
import 'package:travel_ease/UserSide/BookTour.dart';

import '../constants.dart';

class TourDetailScreen extends StatelessWidget {
  final Map<String, dynamic> data;

  TourDetailScreen({required this.data});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFC5DDFF),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(60.0),
        child: AppBar(
          backgroundColor: const Color(0xFFC5DDFF),
          leading: IconButton(
            icon: Image.asset(
              "images/back.png",
              height: 70,
              width: 70,
              // height: MediaQuery.of(context).size.height,
              // width: MediaQuery.of(context).size.width,
            ), // Customize your drawer icon here
            onPressed: () {
              Get.back();
            },
          ),
          title: Text(
            'Tour Details',
            style: TextStyle(
                color: Color(0xff323643), fontWeight: FontWeight.bold),
          ),
          centerTitle: true, // Center the title
        ),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(5.0),
                  child: Image.network(
                    data["imageURL"], // Change to imageURL
                    width: double.infinity,
                    height: 380,
                    fit: BoxFit.fill,
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Tour Ratings: ',
                      style: TextStyle(
                          color: Color(0xff323643),
                          fontWeight: FontWeight.bold,
                          fontSize: 20),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Icon(
                          Icons.star_rate,
                          color: Colors.green,
                          size: 30,
                        ),
                        Text(
                          "4.5",
                          style: TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.w400,
                            color: Color.fromARGB(255, 135, 138, 147),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                Divider(
                  color: Colors.grey, // Color of the divider line
                  thickness: 1, // Thickness of the divider line
                ),
                Text(
                  'Tour Title: ',
                  style: TextStyle(
                      color: Color(0xff323643),
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
                Text(
                  data["title"],
                  style: TextStyle(
                      color: Color(0xff323643),
                      fontWeight: FontWeight.w400,
                      fontSize: 18),
                ),
                Divider(
                  color: Colors.grey, // Color of the divider line
                  thickness: 1, // Thickness of the divider line
                ),
                Text(
                  'Tour description: ',
                  style: TextStyle(
                      color: Color(0xff323643),
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
                Text(
                  data["description"],
                  style: TextStyle(
                      color: Color(0xff323643),
                      fontWeight: FontWeight.w400,
                      fontSize: 18),
                ),
                Divider(
                  color: Colors.grey, // Color of the divider line
                  thickness: 1, // Thickness of the divider line
                ),
                Text(
                  'Tour place name: ',
                  style: TextStyle(
                      color: Color(0xff323643),
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
                Text(
                  data["placeName"],
                  style: TextStyle(
                      color: Color(0xff323643),
                      fontWeight: FontWeight.w400,
                      fontSize: 18),
                ),
                Divider(
                  color: Colors.grey, // Color of the divider line
                  thickness: 1, // Thickness of the divider line
                ),
                Text(
                  'Tour dates: ',
                  style: TextStyle(
                      color: Color(0xff323643),
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
                Text(
                  data["dates"],
                  style: TextStyle(
                      color: Color(0xff323643),
                      fontWeight: FontWeight.w400,
                      fontSize: 18),
                ),
                Divider(
                  color: Colors.grey, // Color of the divider line
                  thickness: 1, // Thickness of the divider line
                ),
                Text(
                  'Departure City: ',
                  style: TextStyle(
                      color: Color(0xff323643),
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
                Text(
                  data["departureCity"],
                  style: TextStyle(
                      color: Color(0xff323643),
                      fontWeight: FontWeight.w400,
                      fontSize: 18),
                ),
                Divider(
                  color: Colors.grey, // Color of the divider line
                  thickness: 1, // Thickness of the divider line
                ),
                Text(
                  'Itinerary: ',
                  style: TextStyle(
                      color: Color(0xff323643),
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
                Text(
                  data["itinerary"],
                  style: TextStyle(
                      color: Color(0xff323643),
                      fontWeight: FontWeight.w400,
                      fontSize: 18),
                ),
                Divider(
                  color: Colors.grey, // Color of the divider line
                  thickness: 1, // Thickness of the divider line
                ),
                Text(
                  'Cost Per Person: ',
                  style: TextStyle(
                      color: Color(0xff323643),
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
                Text(
                  "Rs ${data["costPerPerson"]}",
                  style: TextStyle(
                      color: Color(0xff323643),
                      fontWeight: FontWeight.w400,
                      fontSize: 18),
                ),
                SizedBox(
                  height: 20,
                ),
                CustomButton(
                  buttonText: 'Book Tour',
                  onPressed: () {
                    // Print the values of variables for verification

                    Get.to(() => TourBookScreen(data: data));
                  },
                ),
                SizedBox(
                  height: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
